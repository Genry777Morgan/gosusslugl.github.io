import asyncio
import os
import pathlib
import traceback
import typing as ty
import urllib.parse

import click
import python_socks
import telethon

# Исходный код слит в телеграм канале @END_SOFT
async def make_telegram_client(
    phone_number: str, config: dict
) -> telethon.TelegramClient:
    """
    Создает сессию для определенного аккаунта. Если аккаунт
    заблокирован, предлагает удалить

    :param phone_number: Номер телефона аккаунта
    :param config: Текущий конфиг
    """
    session_path = pathlib.Path("sessions") / phone_number
    if config["proxies"]:
        for proxy in config["proxies"]:
            client = telethon.TelegramClient(
                str(session_path),
                config["app"]["id"],
                config["app"]["hash"],
                proxy=proxy,
            )
            try:
                await client.start(  # noqa
                    phone=lambda: str(phone_number),
                    code_callback=lambda: click.prompt(
                        f"Введите код подтверждения, пришедший на номер `{phone_number}` (отправлен и в телеграмме, и по смс)"
                    ),
                    force_sms=True,
                )
                client.phone = phone_number
            except ConnectionError:
                click.secho(
                    f"Не удалось подключиться к прокси {proxy['addr']}",
                    fg="red",
                )
            else:
                click.secho(
                    f"Удалось подключиться к прокси! Используется `{proxy['addr']}`",
                    fg="green",
                )
                return client
        click.secho("Не удалось подключиться ни к одному из прокси", fg="red")
        exit(1)

    else:
        client = telethon.TelegramClient(
            str(session_path),
            config["app"]["id"],
            config["app"]["hash"],
        )
        await client.start(  # noqa
            phone=lambda: str(phone_number),
            code_callback=lambda: click.prompt(
                f"Введите код подтверждения, пришедший на номер `{phone_number}` (отправлен и в телеграмме, и по смс)"
            ),
            force_sms=True,
        )
        client.phone = phone_number
        return client

# Исходный код слит в телеграм канале @END_SOFT

async def fetch_spam_clients(config: dict):
    spam_accounts_clients = []
    with open("accounts.txt") as accounts:
        spam_phone_numbers = accounts.read().split()
        spam_phone_numbers = set(spam_phone_numbers)
        remain_phones = spam_phone_numbers.copy()
        for phone_number in spam_phone_numbers:
            try:
                spam_client = await make_telegram_client(phone_number, config)
            except Exception:
                with open("registration.err", "w+") as err_log:
                    traceback.print_exc(file=err_log)
                remove_account = click.confirm(
                    f"Аккаунт с номером `{phone_number}` не удалось зарегистрировать, "
                    "вероятно, аккаунт был заблокирован. "
                    "Удалить номер из списка спам-аккаунтов?",
                    default=True,
                )
                if remove_account:
                    remain_phones.remove(phone_number)
            else:
                spam_accounts_clients.append(spam_client)

    with open("accounts.txt", "w") as accounts:
        accounts.write("\n".join(remain_phones))

    if not spam_accounts_clients:
        click.echo(
            "Для работы спам-бота необходим хотя бы один аккаунт. "
            "Добавьте номер телефона в файл `accounts.txt`"
        )
        exit(1)

    return spam_accounts_clients

# Исходный код слит в телеграм канале @END_SOFT
async def _get_members(
    attack_client: telethon.TelegramClient, chat_link: str
) -> ty.Tuple[telethon.TelegramClient, ty.List[telethon.types.User]]:
    members = [
        member async for member in attack_client.iter_participants(chat_link)
    ]
    return attack_client, members
# Исходный код слит в телеграм канале @END_SOFT

def _distribute(routed_entities: dict) -> dict:
    step = len(routed_entities)
    distributed_members = {}
    for start_step, route in enumerate(routed_entities.items()):
        attacker, members = route
        actual_members = [
            member
            for ind, member in enumerate(members)
            if not ((ind + start_step) % step)
        ]
        distributed_members[attacker] = actual_members

    return distributed_members
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
def distribute_database_users(
    spam_clients: ty.List[telethon.TelegramClient],
) -> ty.Dict[telethon.TelegramClient, ty.List[str]]:
    file = click.prompt(
        "Введите имя файла без расширения, "
        "в котором находятся пользователи "
        "(файл должен быть помещён в parsed_users)"
    )
    path = pathlib.Path("parsed_users") / f"{file}.txt"
    with open(str(path), "r") as db:
        members = db.read().split()

    routed_members = {spam_client: members for spam_client in spam_clients}
# Исходный код слит в телеграм канале @END_SOFT
    return _distribute(routed_members)
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
async def distribute_members(
    attack_clients: ty.List[telethon.TelegramClient], chat_link: str
) -> ty.Dict[telethon.TelegramClient, ty.List[telethon.types.User]]:
    members_coroutines = [
        _get_members(attack_client, chat_link)
        for attack_client in attack_clients
    ]
    routed_members = dict(await asyncio.gather(*members_coroutines))
    distributed_members = _distribute(routed_members)
    return distributed_members
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
def get_message() -> str:
    with open("message.txt", encoding="utf-8") as message:
        message = message.read()

    if not message:
        click.echo("Добавьте текст сообщения в файл `message.txt`")
        exit(1)

    return message
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
def parse_proxies(config: dict):
    with open("proxies.txt") as file:
        proxies_text = file.read().split("\n")
        config["proxies"] = []
        for line in proxies_text:
            if line.startswith("#"):
                continue
            else:
                proxy_settings = urllib.parse.urlparse(line)
                proxy_data = {
                    "addr": proxy_settings.hostname,
                    "port": proxy_settings.port,
                }
                if proxy_settings.username and proxy_settings.password:
                    proxy_data["username"] = proxy_settings.username
                    proxy_data["password"] = proxy_settings.password

                if proxy_settings.scheme == "http":
                    proxy_data["proxy_type"] = "http"

                if proxy_settings.scheme == "socks5":
                    proxy_data["proxy_type"] = "socks5"

                if proxy_settings.scheme == "socks4":
                    proxy_data["proxy_type"] = "socks4"

                config["proxies"].append(proxy_data)
# Исходный код слит в телеграм канале @END_SOFT