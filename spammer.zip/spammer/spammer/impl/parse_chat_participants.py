import asyncio
import pathlib

import click
import loguru

import _utils


async def parse_chat_participants(config: dict) -> None:
    """
    Запускает спам в лс по участникам чата

    :param config: Конфиг с ID и hash приложения
    """
    spam_accounts_clients = await _utils.fetch_spam_clients(config)
    try:
        main_account = spam_accounts_clients[0]
        chat_link = click.prompt(
            "Введите ссылку на чат или его короткое имя, участники которого будут записаны"
        )
        loguru.logger.info("Сбор участников беседы...")
        chat = await main_account.get_entity(chat_link)
        members = [
            member async for member in main_account.iter_participants(chat)
        ]
        chat_username = chat.username or f"#{chat.id}&{chat.access_hash}"
        file_name = f"{chat_username}.txt"
        path = pathlib.Path("parsed_users") / file_name
        if not path.exists():
            path.touch()

        data = [
            member.username
            for member in members
            if member.username is not None
        ]
        path.write_text("\n".join(data), encoding="utf-8")

        loguru.logger.success(
            "✓ Парсинг пользователей закончился успешно. "
            "Пользователи сохранены в файле `{file}` в папке `parsed_users`",
            file=file_name,
        )

    finally:
        await asyncio.gather(
            *[client.disconnect() for client in spam_accounts_clients]
        )
