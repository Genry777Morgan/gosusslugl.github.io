import asyncio

import click
import loguru
import telethon
import tqdm
from telethon.tl.functions.channels import InviteToChannelRequest

import _utils


async def invite_chat_participants(config: dict, from_db: bool) -> None:
    spam_accounts_clients = await _utils.fetch_spam_clients(config)
    try:
        main_account = spam_accounts_clients[0]
        if from_db:
            members = _utils.distribute_database_users([main_account])[
                main_account
            ]
        else:
            chat_link = click.prompt(
                "Введите ссылку на чат или его короткое имя, откуда нужно брать пользователей"
            )
            members = [
                member
                async for member in main_account.iter_participants(chat_link)
            ]
            loguru.logger.info("Получение участников чата...")

        invite_shelter = click.prompt(
            "Введите ссылку на чат или его короткое имя, куда нужно приглашать"
        )
        loguru.logger.info("Запуск инвайтинга")
        invited_pack = []
        added_members = [
            member.username
            async for member in main_account.iter_participants(invite_shelter)
            if member.username is not None
        ]
        for member in tqdm.tqdm(
            members, desc="Рассылка приглашений", ascii=" " + ">" * 9 + "-"
        ):
            if (isinstance(member, str) and member not in added_members) or (
                isinstance(member, telethon.types.User)
                and member.username is not None
                and member.username not in added_members
            ):
                invited_pack.append(member)

            if len(invited_pack) == 20:
                try:
                    res = await main_account(
                        InviteToChannelRequest(invite_shelter, invited_pack)
                    )
                    await asyncio.sleep(config["delay"] * 10)
                    invited_pack.clear()
                except Exception as err:
                    loguru.logger.opt(colors=True).warning("{err}", err=err)

        if invited_pack:
            await main_account(
                InviteToChannelRequest(invite_shelter, invited_pack)
            )
        loguru.logger.opt(colors=True).success(
            "Инвайтинг прошел успешно!",
        )
    finally:
        await asyncio.wait(
            [client.disconnect() for client in spam_accounts_clients]
        )
