import os
import pathlib

import click
import telethon


async def load_accounts(config: dict):
    spam_session_files = [
        f.split(".")[0]
        for f in os.listdir("feed_sessions")
        if f.endswith(".session")
    ]
    if not spam_session_files:
        click.secho("Не найдено сессий в папке `feed_sessions`", fg="red")
        return

    added = 0
    with open("./utils/accounts.txt") as accounts:
        exist_accounts = set(accounts.read().split())
    for spam_session_file in spam_session_files:
        session_path = pathlib.Path("feed_sessions") / spam_session_file
        try:
            client = telethon.TelegramClient(
                str(session_path),
                config["app"]["id"],
                config["app"]["hash"],
            )
            await client.start()  # noqa
            me = await client.get_me()
        except Exception:
            pass
        else:
            old_session_path = f"{session_path}.session"
            with open(old_session_path, "rb") as old_session_file:
                old_session_content = old_session_file.read()

            new_session_path = (
                pathlib.Path("sessions") / f"{me.phone}.session"
            )
            with open(new_session_path, "wb+") as new_session_file:
                new_session_file.write(old_session_content)

            try:
                await client.disconnect()
            except Exception:
                pass

            exist_accounts.add(me.phone)
            os.remove(old_session_path)

            journal_path = f"{session_path}.session-journal"
            if os.path.exists(journal_path):
                os.remove(journal_path)

            added += 1

    with open("./utils/accounts.txt", "w+") as new_accounts:
        new_accounts.write("\n".join(exist_accounts))

    click.secho(
        "Удалось добавить {} новых аккаунтов!".format(
            click.style(str(added), fg="bright_green")
        ),
        color="green",
    )
