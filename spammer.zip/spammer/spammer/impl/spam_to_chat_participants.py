import asyncio
import typing as ty

import click
import loguru
import telethon

import _utils


async def spam_to_chat_participants(config: dict, from_db: bool) -> None:
    """
    Запускает спам в лс по участникам чата

    :param config: Конфиг с ID и hash приложения
    """
    spam_accounts_clients = await _utils.fetch_spam_clients(config)
    try:
        message = _utils.get_message()
        if from_db:
            distributed_targets = _utils.distribute_database_users(
                spam_accounts_clients
            )
        else:
            chat_link = click.prompt(
                "Введите ссылку на чат или его короткое имя, участники которого будут проспамлены"
            )
            loguru.logger.info("Получение участников чата...")
            distributed_targets = await _utils.distribute_members(
                spam_accounts_clients, chat_link
            )

        spam_coroutines = []

        for spam_client, targets in distributed_targets.items():
            spam_coroutines.append(
                _spam_targets(
                    spam_client=spam_client,
                    delay=config["delay"],
                    message=message,
                    targets=targets,
                )
            )

        loguru.logger.success("Запуск спама")
        await asyncio.gather(*spam_coroutines)
        loguru.logger.success("Спам прошел успешно!")
    finally:
        await asyncio.gather(
            *[client.disconnect() for client in spam_accounts_clients]
        )


async def _spam_targets(
    spam_client: telethon.TelegramClient,
    targets: ty.List[telethon.types.User],
    message: str,
    delay: float,
):
    """
    Спам определенных целей заданным сообщение

    :param spam_client: Клиент спам-аккаунта
    :param targets: Цели, которые получат рассылку от этого аккаунта
    :param delay: Задержка между запросами
    :param message: Сообщение, которое будет отправлено каждому в лс
    """
    for target in targets:
        while True:
            try:
                await spam_client.send_message(target, message)
                if isinstance(target, str):
                    user_name = target
                else:
                    user_name = target.username or f"id{target.id}"
                phone_number = spam_client.phone
                loguru.logger.opt(colors=True).info(
                    "Отправлено сообщение пользователю <n><g>{user_name}</g></n> с номера <n><g>{phone_number}</g></n>",
                    user_name=user_name,
                    phone_number=phone_number,
                )

            except telethon.errors.rpc_errors_dict["PEER_FLOOD"]:
                loguru.logger.warning(
                    "Слишком много запросов с номера `{phone_number}`. "
                    "До следующей отправки сообщения с этого номера: {delay} секунд",
                    phone_number=spam_client.phone,
                    delay=delay * 2,
                )
                await asyncio.sleep(delay)
            except Exception as err:
                loguru.logger.error("Произошла ошибка: {err}", err=err)
            finally:
                await asyncio.sleep(delay)
                break
