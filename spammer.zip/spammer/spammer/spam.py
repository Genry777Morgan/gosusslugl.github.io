import asyncio
import os
import pathlib
import sys
import uuid
# Исходный код слит в телеграм канале @END_SOFT
import click
import loguru
import requests
import toml
# Исходный код слит в телеграм канале @END_SOFT
from _utils import parse_proxies
from impl.invite_chat_participants import invite_chat_participants
from impl.load_accounts import load_accounts
from impl.parse_chat_participants import parse_chat_participants
from impl.spam_to_chat_participants import spam_to_chat_participants
# Исходный код слит в телеграм канале @END_SOFT
__version__ = "0.3.0"
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
loguru.logger.remove()
loguru.logger.add(
    sys.stdout,
    format="<lvl>[</lvl><c>{time:HH:mm:ss.SSS}</c><lvl>]</lvl> <lvl>{message}</lvl>",
)
# Исходный код слит в телеграм канале @END_SOFT

CHOICES = [
    (
        "Спаммер",
        "Указать чат, участникам которого будет отправлено личное сообщение с текстом из `message.txt`",
    ),
    (
        "Инвайтер",
        "Указать чат, участникам которого будет отправлено приглашение в чат",
    ),
    (
        "Парсер",
        "Записывает участников чата в текстовик"
    ),
    (
        "Спаммер с базы",
        "Проспамить пользователей из текстового файла, помещенного в папке `parsed_users`",
    ),
    (
        "Инвайтер с базы",
        "Пригласить пользователей из текстового файла, помещенного в папке `parsed_users`, в чат",
    ),
    (
        "Загрузить аккаунты",
        "Все найденные сессии в папке `feed_session` будут добавлены в используемые аккаунты",
    ),
]
# Исходный код слит в телеграм канале @END_SOFT
# [1] Спаммер: Указать чат, ...
CHOICES = "\n".join(
    "[{0}] {1}: {2}".format(
        click.style(str(ind), fg="yellow"),
        click.style(choice[0], fg="magenta"),
        click.style(choice[1], fg="cyan"),
    )
    for ind, choice in enumerate(CHOICES, 1)
)
CHOICES = click.style(CHOICES, fg="reset")

HEADER = "[Telegram Spammer: {}]\n\n".format(
    click.style(f"v{__version__}", fg="magenta")
)

columns, lines = os.get_terminal_size()
MENU = """
{menu_name}
{choices}

Напишите цифру соответствующего пункта
""".strip().format(
    choices=CHOICES, menu_name=format(" Menu ", f"-^{columns}")
)

MENU = click.style(MENU, fg="green")
MENU = HEADER + MENU
# Исходный код слит в телеграм канале @END_SOFT
# Исход# Исходный код слит в телеграм канале @END_SOFT# Исходный код слит в телеграм канале @END_SOFTный код слит в телеграм канале @END_SOFT
def _setup_config() -> dict:
    config = toml.load("config.toml")

    if "license_key" not in config:
        config["license_key"] = click.prompt("Введите лицензионный ключ")


    if "id" not in config["app"]:
        config["app"]["id"] = click.prompt(
            "Введите ID приложения (api_id), полученный на `https://my.telegram.org/apps`"
        )

    if "hash" not in config["app"]:
        config["app"]["hash"] = click.prompt(
            "Введите hash приложения (api_hash), полученный на `https://my.telegram.org/apps`"
        )

    return config
# Исходный код слит в телеграм канале @END_SOFT
# Исходный код слит в телеграм канале @END_SOFT
async def main():
    config = _setup_config()
    parse_proxies(config)
    try:
        while True:
            click.clear()
            menu_choice = click.prompt(MENU, type=int)
            click.clear()
            if menu_choice == 1:
                await spam_to_chat_participants(config, from_db=False)
            elif menu_choice == 2:
                await invite_chat_participants(config, from_db=False)
            elif menu_choice == 3:
                await parse_chat_participants(config)
            elif menu_choice == 4:
                await spam_to_chat_participants(config, from_db=True)
            elif menu_choice == 5:
                await invite_chat_participants(config, from_db=True)
            elif menu_choice == 6:
                await load_accounts(config)

            return_to_menu = click.confirm("\n\nВернуться в меню?")
            if not return_to_menu:
                click.secho("\nЗавершение работы", fg="green")
                exit(1)
# Исходный код слит в телеграм канале @END_SOFT
    finally:
        with open("config.toml", "w") as file:
            toml.dump(config, file)
# Исходный код слит в телеграм канале @END_SOFT

def check_key(license_key: str) -> None:

    uuid_path = pathlib.Path.home() / ".object_id"
    if not uuid_path.exists():
        uuid_path.touch()
        uuid_path.write_text(uuid.uuid4().hex, encoding="utf-8")

    with open(str(uuid_path), "r", encoding="utf-8") as uuid_file:
        uuid_data = uuid_file.read()

    response = requests.get(
        "link server",
        params={"key": license_key, "mac_address": uuid_data},
    )
    if response.status_code == 403:
        click.secho(
            "Некорректный лицензионный ключ. Обратитесь к продавцу для его получения",
            fg="red",
        )
        exit(1)


if __name__ == "__main__":
    asyncio.run(main())
